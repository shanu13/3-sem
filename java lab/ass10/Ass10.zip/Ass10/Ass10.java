import java.util.*;   
public class Ass10 { 
    public static void main(String[] args) throws InterruptedException 
    { 
        Prodcons b = new Prodcons(); 
  
        Thread k = new Thread(new Runnable() { 
            @Override
            public void run() 
            { 
		try{
                    b.production();
		}
		catch (InterruptedException e) { 
                    e.printStackTrace(); 
                }  
            } 
        }); 
  
        Thread l = new Thread(new Runnable() { 
            @Override
            public void run() 
            { 
		try{
                    b.consumption(); 
		}
		catch (InterruptedException e) { 
                    e.printStackTrace(); 
                } 
            } 
        }); 
  
        k.start(); 
        l.start(); 
  
        k.join(); 
        l.join(); 
    } 
  
 public static class Prodcons { 
        ArrayList<Integer> items = new ArrayList<Integer>(); 
        int n=8; 
        public void production() throws InterruptedException
        { 
            int a=0; 
            while (true) { 
                synchronized (this) 
                { 
                    while (items.size() == n) 
                        wait(); 
  
                    System.out.println("Producer produced item number-"
                                       + a); 
  
                    items.add(a++); 
                    notify(); 
                    Thread.sleep(2000); 
                } 
            } 
        } 
  
        public void consumption() throws InterruptedException
        { 
            while (true) { 
                synchronized (this) 
                { 
                    while (items.size() == 0) 
                        wait();  
                    int val = items.get(0);
			items.remove(0); 
  
                    System.out.println("Consumer consumed item number-"
                                       + val); 
  
                    notify(); 
  
                    Thread.sleep(2000); 
                } 
            } 
        } 
    } 
} 